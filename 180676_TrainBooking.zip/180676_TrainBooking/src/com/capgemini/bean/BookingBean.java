package com.capgemini.bean;

public class BookingBean {
	private int bookingid;
	private int noOfSeat;
	private int trainid;
	private String custid;


	public BookingBean(int bookingid, int noOfSeat, int trainid, String custid) {
		super();
		this.bookingid = bookingid;
		this.noOfSeat = noOfSeat;
		this.trainid = trainid;
		this.custid = custid;
	}

	public BookingBean() {
	
	}

	public int getBookingid() {
		return bookingid;
	}

	public void setBookingid(int bookingid) {
		this.bookingid = bookingid;
	}

	public int getNoOfSeat() {
		return noOfSeat;
	}

	public void setNoOfSeat(int noOfSeat) {
		this.noOfSeat = noOfSeat;
	}

	public int getTrainid() {
		return trainid;
	}

	public void setTrainid(int trainid) {
		this.trainid = trainid;
	}

	public String getCustid() {
		return custid;
	}

	public void setCustid(String custid) {
		this.custid = custid;
	}

	@Override
	public String toString() {
		return "BookingBean [bookingid=" + bookingid + ", noOfSeat=" + noOfSeat + ", trainid=" + trainid + ", custid="
				+ custid + "]";
	}

	

}
