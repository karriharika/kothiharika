package com.capgemini.service;

import java.util.regex.Pattern;

public class TrainValidator {

	public static boolean validateCustomerId(String customerid) {
		if (Pattern.matches("[A-Z][0-9]{6}", customerid))
			return true;
		else
			return false;
	}

}
