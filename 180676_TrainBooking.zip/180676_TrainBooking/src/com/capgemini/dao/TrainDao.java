package com.capgemini.dao;


import java.util.List;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.ttb.exception.BookingException;


public interface TrainDao {

	public List<TrainBean> retrieveTrainDetails() throws BookingException;

	int bookTicket(BookingBean bookingBean) throws BookingException;
}
