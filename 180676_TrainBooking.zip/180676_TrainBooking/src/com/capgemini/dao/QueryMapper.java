package com.capgemini.dao;

public class QueryMapper {

	public static final String RETRIVE_ALL_TRAIN_QUERY="select trainId, trainType, fromStop, toStop, fare, availableSeats, dateOfJourney from traindetails";
	public static final String INSERT_BOOKING_QUERY =  "INSERT INTO BookingDetails VALUES(?,?,?,?)";
	public static final String BOOKINGID_SEQUENCE_QUERY="SELECT Booking_Id_Seq.nextval FROM dual";
	
}




