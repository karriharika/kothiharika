package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.Util.DBUtil;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.ttb.exception.BookingException;


public class TrainDaoImpl implements TrainDao {
	Connection conn = null;
		@Override
		public int bookTicket(BookingBean bookingBean) throws BookingException {
			conn = DBUtil.getConnection();
			int bookingid = generateBookingId();
			bookingBean.setBookingid(bookingid);
			//String sql = "INSERT INTO BookingDetails VALUES(?,?,?,SYSDATE,?)";
			
			try {
				conn.setAutoCommit(false);
				PreparedStatement pst = conn.prepareStatement(QueryMapper.INSERT_BOOKING_QUERY);
				
				pst.setInt(1, bookingid);
				pst.setString(2, bookingBean.getCustid());
				pst.setInt(3, bookingBean.getTrainid());
				pst.setInt(4, bookingBean.getNoOfSeat());
				
				/*ResultSet rst = pst.executeQuery();*/
				pst.executeUpdate();
				conn.rollback();
			} catch (SQLException e) {
				throw new BookingException(e.getMessage());
			}
			try {
				conn.setAutoCommit(false);
			} catch (SQLException e) {
				e.getMessage();
			}
			return bookingid;
		}

		private int generateBookingId() throws BookingException {
			//String sql = "SELECT Booking_Id_Seq.nextval FROM dual";
			int bookingid = 0;
			try {
				PreparedStatement st = conn.prepareStatement(QueryMapper.BOOKINGID_SEQUENCE_QUERY);
				ResultSet rs = st.executeQuery();
				if (rs.next())
					bookingid = rs.getInt(1);
			} catch (SQLException e) {
				throw new BookingException(e.getMessage());
			}
			return bookingid;
		}

		@Override
		public List<TrainBean> retrieveTrainDetails() throws BookingException {
			List<TrainBean> list = new ArrayList<TrainBean>();
			//String sql = "select trainId, trainType, fromStop, toStop, fare, availableSeats, dateOfJourney from traindetails";
			conn = DBUtil.getConnection();
			try {
				
				PreparedStatement statement = conn.prepareStatement(QueryMapper.RETRIVE_ALL_TRAIN_QUERY);
				ResultSet set = statement.executeQuery();
				while (set.next()) {
					TrainBean trainBean = new TrainBean();
					trainBean.setTrainid(set.getInt("trainId"));
					trainBean.setTrainType(set.getString("trainType"));
					trainBean.setFromStop(set.getString("fromStop"));
					trainBean.setToStop(set.getString("toStop"));
					trainBean.setFare(set.getInt("fare"));
					trainBean.setAvailableSeats(set.getInt("availableSeats"));
					trainBean.setDateOfJourney(set.getDate("dateOfJourney").toLocalDate());
					list.add(trainBean);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new BookingException("Error in fetching Details");
			}

			return list;
		}
	
}
